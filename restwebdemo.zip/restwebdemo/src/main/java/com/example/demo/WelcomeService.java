package com.example.demo;

import org.springframework.stereotype.Service;

@Service
public class WelcomeService {
 
	 public String getWelcomeMessage() 
	 {
		 return "<h2> Good Afternoon </h2>";
	 }
	
}
