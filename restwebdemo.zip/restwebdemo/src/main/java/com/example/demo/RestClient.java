package com.example.demo;

import org.springframework.web.client.RestTemplate;

public class RestClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		final String uri = "http://localhost:8080/welcomemessage/Anil";
		
		RestTemplate restTemplate = new RestTemplate();
		String result = restTemplate.getForObject(uri, String.class);
		System.out.println(result);

		
	}

}
