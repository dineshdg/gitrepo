
/**
 * CalculatorImplServiceSkeletonInterface.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.4.1  Built on : Aug 13, 2008 (05:03:35 LKT)
 */
    package com.pkg.capgemini.springsoapwebservicedemo;
    /**
     *  CalculatorImplServiceSkeletonInterface java skeleton interface for the axisService
     */
    public interface CalculatorImplServiceSkeletonInterface {
     
         
        /**
         * Auto generated method signature
         * 
                                    * @param add
         */

        
                public com.pkg.capgemini.springsoapwebservicedemo.AddResponse add
                (
                  com.pkg.capgemini.springsoapwebservicedemo.Add add
                 )
            ;
        
         }
    