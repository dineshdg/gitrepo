/**
 * 
 */
package com.pkg.capgemini.loginSpringbootMVC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * @author digadade
 *
 */
@SpringBootApplication
@EnableDiscoveryClient
public class MvcApplication {

	public static void main(String[] args){
		SpringApplication.run(MvcApplication.class, args);
	}
}
