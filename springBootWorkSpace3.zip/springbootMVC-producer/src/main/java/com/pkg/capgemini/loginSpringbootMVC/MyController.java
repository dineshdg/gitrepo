/**
 * 
 */
package com.pkg.capgemini.loginSpringbootMVC;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.pkg.capgemini.loginSpringbootMVC.service.CurencyConvertorService;
import com.pkg.capgemini.loginSpringbootMVC.service.LoginService;

/**
 * @author digadade
 *
 */
@RestController
public class MyController {
	
	@Autowired
	LoginService loginservice;
	
	@Autowired
	CurencyConvertorService curencyConvertorService;

	/*@RequestMapping(value="/login", method=RequestMethod.GET)
	public String loginPage(ModelMap modelMap){
		return "login";
	}
	
	@RequestMapping(value="/login",method=RequestMethod.POST)
	public String validateUser(ModelMap modelMap, @RequestParam String uname, @RequestParam String password){
		if(loginservice.validateUserDetails(uname,password)){
			modelMap.put("uname", uname);
			return "success";
		}else{
			modelMap.put("errormsg", "Invalid details !");
			return "login";
		}
	}*/
	
	@RequestMapping(value="/convertor",method=RequestMethod.POST)
	public String convertCurrency(ModelMap modelMap, @RequestParam String doller){
		Double inr ;
		if(doller == null || doller == ""){
			modelMap.put("errormsg", "please enetr doller value");
		}else if(!doller.matches("^\\d+$")){
			modelMap.put("errormsg", "please enetr only digits");
		}else{
			Double dollerValue = Double.parseDouble(doller);
			inr = curencyConvertorService.covertDollerToInr(dollerValue);
			modelMap.put("inr", inr);
		}
		return "success";
	}
}
