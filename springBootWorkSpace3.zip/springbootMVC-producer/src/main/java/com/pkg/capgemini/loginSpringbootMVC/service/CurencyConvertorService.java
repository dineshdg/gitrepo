/**
 * 
 */
package com.pkg.capgemini.loginSpringbootMVC.service;

/**
 * @author digadade
 *
 */
public interface CurencyConvertorService {

	Double covertDollerToInr(Double doller);

}
