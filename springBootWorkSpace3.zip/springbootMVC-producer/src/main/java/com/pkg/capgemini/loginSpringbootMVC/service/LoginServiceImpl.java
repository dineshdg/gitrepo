/**
 * 
 */
package com.pkg.capgemini.loginSpringbootMVC.service;

import org.springframework.stereotype.Service;

/**
 * @author digadade
 *
 */
@Service
public class LoginServiceImpl implements LoginService {

	/* (non-Javadoc)
	 * @see com.pkg.capgemini.loginSpringbootMVC.service.LoginService#validateUserDetails(java.lang.String, java.lang.String)
	 */
	@Override
	public boolean validateUserDetails(String uname, String password) {
		if(uname.equalsIgnoreCase("abc") && password.equalsIgnoreCase("123"))
			return true;
		return false;
	}

}
