/**
 * 
 */
package com.pkg.capgemini.loginSpringbootMVC.service;

import org.springframework.stereotype.Service;

/**
 * @author digadade
 *
 */

@Service
public class CurencyConvertorServiceImpl implements CurencyConvertorService {

	/* (non-Javadoc)
	 * @see com.pkg.capgemini.loginSpringbootMVC.service.CurencyConvertorService#covert(java.lang.Double)
	 */
	@Override
	public Double covertDollerToInr(Double doller) {
		return doller * 65.33; 
	}

}
