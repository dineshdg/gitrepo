/**
 * 
 */
package com.pkg.capgemini.loginSpringbootMVC.service;

/**
 * @author digadade
 *
 */
public interface LoginService {

	boolean validateUserDetails(String uname, String password);

}
