/**
 * 
 */
package com.pkg.capgemini.loginSpringbootMVC.configuration;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * @author digadade
 *
 */
@Configuration
public class MyMvcconfig extends WebMvcConfigurerAdapter{
	
	@Override
	public void addViewControllers(ViewControllerRegistry registry){
		registry.addViewController("/success").setViewName("success");
		registry.addViewController("/").setViewName("login");
		registry.addViewController("/login").setViewName("login");
	}

}
