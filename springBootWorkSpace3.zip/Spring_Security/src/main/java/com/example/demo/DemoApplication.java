package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;

import com.services.Welcome;

@SpringBootApplication
@ComponentScan({"com.services","com.dao.service"})

public class DemoApplication {

		
	public static void main(String[] args) {
		ApplicationContext ctx= SpringApplication.run(DemoApplication.class, args);
    Welcome msg= (Welcome) ctx.getBean(Welcome.class);
	System.out.println(msg.welcome());

	
	}
}
