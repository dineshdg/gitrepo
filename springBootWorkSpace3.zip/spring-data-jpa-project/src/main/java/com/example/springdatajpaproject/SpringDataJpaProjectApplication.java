package com.example.springdatajpaproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJpaProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaProjectApplication.class, args);
	}
	

}
