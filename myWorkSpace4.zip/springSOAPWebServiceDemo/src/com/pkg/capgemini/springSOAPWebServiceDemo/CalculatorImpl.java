/**
 * 
 */
package com.pkg.capgemini.springSOAPWebServiceDemo;

import javax.jws.WebService;

/**
 * @author digadade
 *
 */
@WebService(endpointInterface="com.pkg.capgemini.springSOAPWebServiceDemo.Calculator")
public class CalculatorImpl implements Calculator{

	@Override
	public int add(int x, int y) {
		return x+y;
	}

}
