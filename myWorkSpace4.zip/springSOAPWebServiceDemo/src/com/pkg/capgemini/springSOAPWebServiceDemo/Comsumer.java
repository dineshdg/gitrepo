/**
 * 
 */
package com.pkg.capgemini.springSOAPWebServiceDemo;

import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.stream.events.Namespace;
import javax.xml.ws.Service;

/**
 * @author digadade
 *
 */
public class Comsumer {

	/**
	 * @param args
	 * @throws MalformedURLException 
	 */
	public static void main(String[] args) throws MalformedURLException {
		URL url =  new URL("http://localhost:8081/cg/?wsdl");
		QName qName = new QName("http://springSOAPWebServiceDemo.capgemini.pkg.com/","CalculatorImplService");
		Service service = Service.create(url, qName);
		Calculator calculator = service.getPort(Calculator.class);
		int result = calculator.add(10, 20);
		System.out.println("Result :"+result);
	}

}
