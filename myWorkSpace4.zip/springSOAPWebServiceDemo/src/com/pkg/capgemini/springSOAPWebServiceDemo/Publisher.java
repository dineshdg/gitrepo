/**
 * 
 */
package com.pkg.capgemini.springSOAPWebServiceDemo;

import javax.xml.ws.Endpoint;

/**
 * @author digadade
 *
 */
public class Publisher {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Endpoint.publish("http://localhost:8081/cg", new CalculatorImpl());
		System.out.println("Service is published !");
	}

}
