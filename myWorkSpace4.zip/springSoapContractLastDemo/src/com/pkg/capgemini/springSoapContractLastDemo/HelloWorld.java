/**
 * 
 */
package com.pkg.capgemini.springSoapContractLastDemo;

/**
 * @author digadade
 *
 */
public class HelloWorld {

	public String sayHello(){
		return "Hello !";
	}
}
