package com.pkg.capgemini.trainee.dao;

import com.pkg.capgemini.trainee.dataModel.Trainee;

public interface TraineeMgmtDAO {

	String verifyUser(Trainee trainee);

	Trainee addTrainee(Trainee trainee) throws Exception;

	Trainee searchTrainee(int id);

}
