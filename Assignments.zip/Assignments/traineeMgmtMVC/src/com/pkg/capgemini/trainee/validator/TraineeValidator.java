/**
 * 
 */
package com.pkg.capgemini.trainee.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.pkg.capgemini.trainee.dataModel.Trainee;

/**
 * @author digadade
 *
 */
public class TraineeValidator implements Validator{

	@Override
	public boolean supports(Class<?> arg0) {
		return Trainee.class.isAssignableFrom(arg0);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userId", "user.id.empty");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userPassword", "user.password.empty");
		
		Trainee trinee = (Trainee) obj;
	}

}
