package com.pkg.capgemini.trainee.service;

import com.pkg.capgemini.trainee.dataModel.Trainee;

public interface TraineeMgmtService {

	String verifyUser(Trainee trainee);

	Trainee addTrainee(Trainee trainee) throws Exception;

	Trainee searchTrainee(int id);

}
