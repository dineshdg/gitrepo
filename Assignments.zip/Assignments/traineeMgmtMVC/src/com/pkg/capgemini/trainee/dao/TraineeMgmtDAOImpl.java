/**
 * 
 */
package com.pkg.capgemini.trainee.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.pkg.capgemini.trainee.dataModel.Trainee;

/**
 * @author digadade
 *
 */
@Component("traineeMgmtDAO")
@Transactional
public class TraineeMgmtDAOImpl implements TraineeMgmtDAO{
	
	@PersistenceContext
	EntityManager em;
	
	@Override
	public String verifyUser(Trainee trainee) {
		String response = "errorsPage";
		/*String sQuery = "select count(*) from cap_user where cap_uid=? and cap_upass=?";
		int result = jt.queryForInt(sQuery, trainee.getUserId(), trainee.getUserPassword());
		if(result > 0)
			response = "success";
		return response;*/
		
		Trainee newtrainee = (Trainee) em.createQuery("SELECT t FROM Trainee t WHERE t.userid=:uid")
        .setParameter("uid", trainee.getUserId()).getSingleResult();
        //.setParameter("upass",trainee.getUserPassword())
        
		if(newtrainee.getId() != 0)
			response = "success";
			
		return response;
	}

	@Override
	public Trainee addTrainee(Trainee trainee) throws Exception {
		em.persist(trainee);
		em.flush();
		if(trainee != null)
			return trainee;
		return null;
	}

	@Override
	public Trainee searchTrainee(int id) {
		return em.find(Trainee.class, id);
	}

}
