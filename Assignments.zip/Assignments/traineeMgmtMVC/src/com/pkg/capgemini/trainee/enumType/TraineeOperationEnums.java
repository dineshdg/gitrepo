/**
 * 
 */
package com.pkg.capgemini.trainee.enumType;

/**
 * @author digadade
 *
 */
public enum TraineeOperationEnums {
	Add, Delete, Modify, Retrieve, RetrieveAll
}
