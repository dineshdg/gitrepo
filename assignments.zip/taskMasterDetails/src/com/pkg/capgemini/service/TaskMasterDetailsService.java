/**
 * 
 */
package com.pkg.capgemini.service;

import java.util.List;

import com.pkg.capgemini.entity.Designation;
import com.pkg.capgemini.entity.Employee;
import com.pkg.capgemini.entity.Levels;
import com.pkg.capgemini.entity.TaskDetails;
import com.pkg.capgemini.entity.TaskMasterDetails;
import com.pkg.capgemini.entity.Users;

/**
 * @author digadade
 *
 */
public interface TaskMasterDetailsService {
	
	boolean validateUser(Users users);

	List<TaskMasterDetails> getAssignedTaskDetails();

	List<Designation> getAllDesignation();

	List<Levels> getAllLevel();

	boolean saveEmployeeDetails(Employee employee);

	boolean saveAssignedTask(TaskMasterDetails taskMasterDetails);

	List<Employee> getAllEmployees();

	List<TaskDetails> getAllTaskDetails();

	boolean saveTaskDetails(TaskDetails taskDetails);

}
