/**
 * 
 */
package com.pkg.capgemini.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pkg.capgemini.dao.TaskMasterDetailsDAO;
import com.pkg.capgemini.entity.Designation;
import com.pkg.capgemini.entity.Employee;
import com.pkg.capgemini.entity.Levels;
import com.pkg.capgemini.entity.TaskDetails;
import com.pkg.capgemini.entity.TaskMasterDetails;
import com.pkg.capgemini.entity.Users;

/**
 * @author digadade
 *
 */

@Service("taskMasterDetailsService")
public class TaskMasterDetailsServiceImpl implements TaskMasterDetailsService {

	@Autowired
	TaskMasterDetailsDAO taskMasterDetailsDAO;
	
	@Override
	public boolean validateUser(Users users) {
		return taskMasterDetailsDAO.validateUser(users);
	}

	@Override
	public List<TaskMasterDetails> getAssignedTaskDetails() {
		return taskMasterDetailsDAO.getAssignedTaskDetails();
	}

	@Override
	public List<Designation> getAllDesignation() {
		return taskMasterDetailsDAO.getAllDesignation();
	}

	@Override
	public List<Levels> getAllLevel() {
		return taskMasterDetailsDAO.getAllLevel();
	}

	@Override
	public boolean saveEmployeeDetails(Employee employee) {
		return taskMasterDetailsDAO.saveEmployeeDetails(employee);
	}

	@Override
	public boolean saveAssignedTask(TaskMasterDetails taskMasterDetails) {
		return taskMasterDetailsDAO.saveAssignedTask(taskMasterDetails);
	}

	@Override
	public List<Employee> getAllEmployees() {
		return taskMasterDetailsDAO.getAllEmployees();
	}

	@Override
	public List<TaskDetails> getAllTaskDetails() {
		return taskMasterDetailsDAO.getAllTaskDetails();
	}

	@Override
	public boolean saveTaskDetails(TaskDetails taskDetails) {
		return taskMasterDetailsDAO.saveTaskDetails(taskDetails);
	}

}
