/**
 * 
 */
package com.pkg.capgemini.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.pkg.capgemini.entity.Designation;
import com.pkg.capgemini.entity.Employee;
import com.pkg.capgemini.entity.Levels;
import com.pkg.capgemini.entity.TaskDetails;
import com.pkg.capgemini.entity.TaskMasterDetails;
import com.pkg.capgemini.entity.Users;

/**
 * @author digadade
 *
 */

@Repository("taskMasterDetailsDAO")
@Transactional
public class TaskMasterDetailsDAOImpl implements TaskMasterDetailsDAO {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public boolean validateUser(Users users) {
		Query query = entityManager.createQuery("from Users u where u.userId=:userId and u.password=:password");
		Users validUser = (Users) query.setParameter("userId", users.getUserId()).setParameter("password", users.getPassword()).getSingleResult();
		if(validUser != null)
			return true;
		return false;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TaskMasterDetails> getAssignedTaskDetails() {
		Query query = entityManager.createQuery("from TaskMasterDetails tmd");
		List<TaskMasterDetails> taskMasterDetails= (List<TaskMasterDetails>) query.getResultList();
		if(taskMasterDetails.size() > 0)
			return taskMasterDetails;
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Designation> getAllDesignation() {
		Query query = entityManager.createQuery("from Designation dsg");
		List<Designation> designation= (List<Designation>) query.getResultList();
		if(designation.size() > 0)
			return designation;
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Levels> getAllLevel() {
		Query query = entityManager.createQuery("from Levels lvl");
		List<Levels> levels= (List<Levels>) query.getResultList();
		if(levels.size() > 0)
			return levels;
		return null;
	}

	@Override
	public boolean saveEmployeeDetails(Employee employee) {
		entityManager.persist(employee);
		entityManager.flush();	//required to reflect changes on database
		
		if(employee.getId() != null)
			return true;
		else
			return false;
	}

	@Override
	public boolean saveAssignedTask(TaskMasterDetails taskMasterDetails) {
		entityManager.persist(taskMasterDetails);
		entityManager.flush();	//required to reflect changes on database
		
		if(taskMasterDetails.getId() != null)
			return true;
		else
			return false;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Employee> getAllEmployees() {
		Query query = entityManager.createQuery("from Employee emp");
		List<Employee> employees= (List<Employee>) query.getResultList();
		if(employees.size() > 0)
			return employees;
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TaskDetails> getAllTaskDetails() {
		Query query = entityManager.createQuery("from TaskDetails td");
		List<TaskDetails> taskDetails= (List<TaskDetails>) query.getResultList();
		if(taskDetails.size() > 0)
			return taskDetails;
		return null;
	}

	@Override
	public boolean saveTaskDetails(TaskDetails taskDetails) {
		entityManager.persist(taskDetails);
		entityManager.flush();	//required to reflect changes on database
		
		if(taskDetails.getId() != null)
			return true;
		else
			return false;
	}

}
