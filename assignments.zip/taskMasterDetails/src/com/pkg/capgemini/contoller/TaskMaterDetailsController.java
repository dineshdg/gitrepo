/**
 * 
 */
package com.pkg.capgemini.contoller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.pkg.capgemini.dto.EmployeeDTO;
import com.pkg.capgemini.dto.TaskDetailsDTO;
import com.pkg.capgemini.dto.TaskMasterDetailsDTO;
import com.pkg.capgemini.entity.Designation;
import com.pkg.capgemini.entity.Employee;
import com.pkg.capgemini.entity.Levels;
import com.pkg.capgemini.entity.TaskDetails;
import com.pkg.capgemini.entity.TaskMasterDetails;
import com.pkg.capgemini.entity.Users;
import com.pkg.capgemini.service.TaskMasterDetailsService;


/**
 * @author digadade
 *
 */
@Controller
public class TaskMaterDetailsController {
	
	@Autowired
	TaskMasterDetailsService taskMasterDetailsService;
	
	static List<Designation> designationList = null;
	static List<Levels> levelList = null;
	static List<Employee> employeeList = null;
	static List<TaskDetails> taskDetailsList = null;
	static Map<String, Object> masterData = null;
	static Map<String, Object> dynamicMasterData = null;
	
	@RequestMapping(value="/login", method=RequestMethod.GET)
	public String loginPage(ModelMap model){
		model.addAttribute("users", new Users());
		return "login";
	}
	
	@RequestMapping(value="/authenticate", method=RequestMethod.POST)
	public ModelAndView authenticateDetails(ModelMap model, @ModelAttribute("users") Users users){
		if(taskMasterDetailsService.validateUser(users)){
			List<TaskMasterDetails> taskMasterDetailList = 
					taskMasterDetailsService.getAssignedTaskDetails();
			employeeList = taskMasterDetailsService.getAllEmployees();
			taskDetailsList = taskMasterDetailsService.getAllTaskDetails();
			
			dynamicMasterData = new HashMap<String, Object>();
			dynamicMasterData.put("taskMasterDetailList", taskMasterDetailList);
			dynamicMasterData.put("employeeList", employeeList);
			dynamicMasterData.put("taskDetailsList", taskDetailsList);
			return new ModelAndView("home","dynamicMasterData",dynamicMasterData);
		}
		return new ModelAndView("login","errorMessage","Please enter valid userid or password !");
	}
	
	@RequestMapping(value="/addEmployee", method=RequestMethod.GET)
	public ModelAndView emplpoyee(ModelMap model){
		designationList = taskMasterDetailsService.getAllDesignation();
		levelList = taskMasterDetailsService.getAllLevel();
		
		masterData = new HashMap<String, Object>();
		masterData.put("designationList", designationList);
		masterData.put("levelList", levelList);
		
		model.addAttribute("employee", new EmployeeDTO());
		return new ModelAndView("addEmployee","masterData",masterData);
		
		/*model.addAttribute("employee", new Employee());
		return new ModelAndView("addEmployee");*/
	}
	
	@RequestMapping(value="/addNewEmployee", method=RequestMethod.POST)
	public ModelAndView addEmployee(ModelMap model, @ModelAttribute("employee") EmployeeDTO employeeDTO, BindingResult result){
		Employee employee = new Employee();
		employee.setEmailId(employeeDTO.getEmailId());
		employee.setFirstName(employeeDTO.getFirstName());
		employee.setLastName(employeeDTO.getLastName());
		employee.setMobileNo(employeeDTO.getMobileNo());
		employee.setStatus(employeeDTO.getStatus());
		
		Designation designation = new Designation();
		designation.setId(employeeDTO.getDesignation());
		employee.setDesignation(designation);
		
		Levels levels = new Levels();
		levels.setId(employeeDTO.getLevels());
		employee.setLevels(levels);
		
		boolean response = taskMasterDetailsService.saveEmployeeDetails(employee);
		if(response)
			return new ModelAndView("home","taskMasterDetailList",null);
		else
			return new ModelAndView("addEmployee","masterData",masterData);
	}
	
	@RequestMapping(value="/addTaskDetails", method=RequestMethod.GET)
	public ModelAndView taskDetails(ModelMap model){
		model.addAttribute("taskDetailsDTO", new TaskDetailsDTO());
		return new ModelAndView("addTaskDetails");
	}
	
	@RequestMapping(value="/addNewTask", method=RequestMethod.POST)
	public ModelAndView addNewTask(ModelMap model, @ModelAttribute("taskDetailsDTO") TaskDetailsDTO taskDetailsDTO, BindingResult result){
		try{
			TaskDetails taskDetails = new TaskDetails();
			taskDetails.setName(taskDetailsDTO.getName());
			taskDetails.setDescription(taskDetailsDTO.getDescription());
			
			Employee createdBy = new Employee();
			createdBy.setId(1L);
			taskDetails.setCreatedBy(createdBy);
			
			taskDetails.setStatus(taskDetailsDTO.getStatus());
			boolean response = taskMasterDetailsService.saveTaskDetails(taskDetails);
			if(response)
				return new ModelAndView("home","taskMasterDetailList",null);
			else
				return new ModelAndView("addEmployee","masterData",masterData);
		}catch(Exception e){
			e.printStackTrace();
			return new ModelAndView("errorPage");
		}
	}
	
	@RequestMapping(value="/assignTask", method=RequestMethod.GET)
	public ModelAndView assignTask(ModelMap model){
		model.addAttribute("taskMasterDetailsDTO", new TaskMasterDetails());
		employeeList = taskMasterDetailsService.getAllEmployees();
		taskDetailsList = taskMasterDetailsService.getAllTaskDetails();
		dynamicMasterData = new HashMap<String, Object>();
		dynamicMasterData.put("employeeList", employeeList);
		dynamicMasterData.put("taskDetailsList", taskDetailsList);
		return new ModelAndView("assignTaskToEmployee","dynamicMasterData",dynamicMasterData);
	}
	
	@RequestMapping(value="/assignNewTask", method=RequestMethod.POST)
	public ModelAndView assignNewTask(ModelMap model, @ModelAttribute("taskMasterDetailsDTO") TaskMasterDetailsDTO taskMasterDetailsDTO, BindingResult result){
		SimpleDateFormat sdf = new SimpleDateFormat("dd MMMM yyyy");
		try{
		TaskMasterDetails taskMasterDetails = new TaskMasterDetails();
		
		TaskDetails taskDetails = new TaskDetails();
		taskDetails.setId(taskMasterDetailsDTO.getTaskDetails());
		taskMasterDetails.setTaskDetails(taskDetails);
		
		Employee assigneTo = new Employee();
		assigneTo.setId(taskMasterDetailsDTO.getAssignedTo());
		taskMasterDetails.setAssignedTo(assigneTo);
		
		Employee assigneBy = new Employee();
		assigneBy.setId(taskMasterDetailsDTO.getAssignedBy());
		taskMasterDetails.setAssignedBy(assigneBy);
		
		Date startDate = sdf.parse(taskMasterDetailsDTO.getStartDate());
		taskMasterDetails.setStartDate(startDate);
		
		Date endDate = sdf.parse(taskMasterDetailsDTO.getEndDate());
		taskMasterDetails.setEndDate(endDate);
		
		taskMasterDetails.setRemark(taskMasterDetailsDTO.getRemark());
		taskMasterDetails.setStatus(taskMasterDetailsDTO.getStatus());
		boolean response = taskMasterDetailsService.saveAssignedTask(taskMasterDetails);
		if(response)
			return new ModelAndView("home","taskMasterDetailList",null);
		else
			return new ModelAndView("assignTaskToEmployee","masterData",masterData);
		}catch(Exception e){
			e.printStackTrace();
			return new ModelAndView("errorPage");
		}
	}
}
