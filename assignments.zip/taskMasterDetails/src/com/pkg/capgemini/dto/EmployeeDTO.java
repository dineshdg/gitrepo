/**
 * 
 */
package com.pkg.capgemini.dto;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author digadade
 *
 */
@XmlRootElement
public class EmployeeDTO {
	
	private String firstName;
	private String lastName;
	private String mobileNo;
	private String emailId;
	private Long designation;
	private Long levels;
	private String status;
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public Long getDesignation() {
		return designation;
	}
	public void setDesignation(Long designation) {
		this.designation = designation;
	}
	public Long getLevels() {
		return levels;
	}
	public void setLevels(Long levels) {
		this.levels = levels;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
