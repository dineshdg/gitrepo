/**
 * 
 */
package com.pkg.capgemini.dto;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author digadade
 *
 */
@XmlRootElement
public class TaskMasterDetailsDTO {
	
	private Long taskDetails;
	private Long assignedTo;
	private Long assignedBy;
	private String startDate;
	private String endDate;
	private String remark;
	private String status;
	
	public Long getTaskDetails() {
		return taskDetails;
	}
	public void setTaskDetails(Long taskDetails) {
		this.taskDetails = taskDetails;
	}
	public Long getAssignedTo() {
		return assignedTo;
	}
	public void setAssignedTo(Long assignedTo) {
		this.assignedTo = assignedTo;
	}
	public Long getAssignedBy() {
		return assignedBy;
	}
	public void setAssignedBy(Long assignedBy) {
		this.assignedBy = assignedBy;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
