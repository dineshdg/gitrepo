say-hello = pom project for microservice

user= pom project for client side load balancing without Eureka consuming say-hello.