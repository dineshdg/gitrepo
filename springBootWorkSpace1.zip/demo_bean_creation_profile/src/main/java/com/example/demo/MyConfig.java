package com.example.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
public class MyConfig {
	
	@Bean
	public String getName()
	{
		return "Anil";
	}
	
	@Bean 
	@Profile("EMP")
	public IPerson emp()
	{
		return new Employee("Anil","L&D");
	}
	
	@Bean 
	@Profile("DEV")
	public IPerson developer()
	{
		return new Developer("Sunil","Apps NA");
	}	
	
}
