package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;



@SpringBootApplication

public class DemoApplication {

	public static void main(String[] args) {
		ApplicationContext ctx= SpringApplication.run(DemoApplication.class, args);
		
		/*
		Employee emp1= (Employee) ctx.getBean(Employee.class);
		System.out.println(emp1.getDetails());
		*/
	
		/*Employee emp2= (Employee) ctx.getBean("emp",Employee.class);
		System.out.println(emp2);
		*/
		
		Developer developer = ctx.getBean("developer", Developer.class);
		System.out.println(developer);
		
/*
		String name= (String) ctx.getBean("getName",String.class);
		System.out.println(name);
*/
		/*
		IPerson person2= (IPerson) ctx.getBean(IPerson.class);
		System.out.println(person2);
		*/
	}
}
