package com.example.demo;

public class Employee implements IPerson  {

	private String name;
	private String dept;
	
	public Employee(String name, String dept)
	{
		this.name = name;
		this.dept = dept;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return this.name + "works in " + this.dept;
	}

	@Override
	public String getDetails() {
		// TODO Auto-generated method stub
		return "Employeee-Employee " + this.name + "works in " + this.dept;
	}
	
	
	
}
