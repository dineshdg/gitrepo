package com.example.demo;

public interface IPerson {
	
	public String getDetails();
}
