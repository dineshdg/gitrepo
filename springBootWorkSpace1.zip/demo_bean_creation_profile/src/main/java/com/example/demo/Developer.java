package com.example.demo;

public class Developer implements IPerson {
	
	private String name;
	private String dept;
	
	public Developer(String name, String dept)
	{
		this.name = name;
		this.dept = dept;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return this.name + "works in " + this.dept;
	}

	@Override
	public String getDetails() {
		// TODO Auto-generated method stub
		return "Developer-Employee " + this.name + "works in " + this.dept;
	}
	

}
