package com.example.demo;

import java.util.List;

public interface UserDAO
{
    List<String> getAllUserNames();
}
