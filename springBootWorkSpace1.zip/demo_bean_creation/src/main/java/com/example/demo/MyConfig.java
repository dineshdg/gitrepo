package com.example.demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MyConfig {
	
	@Value("${my.name}")
	private String myname;

	
	@Bean
	public String getName()
	{
		return myname;
	}
	
	@Bean 
	public Employee emp()
	{
		return new Employee("Anil","L&D");
	}
	
	

}
