/**
 * 
 */
package com.pkg.capgemini.springAOPDemo.advices;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;


/**
 * @author digadade
 *
 */
public class MyAdvice {
	
	public void validate() {
		System.out.println("Security Code");
	}
	
	public void login(){
		System.out.println("login Code");
	}
	
	public void managetransaction(ProceedingJoinPoint joinpoint) throws Throwable{
		System.out.println("before transaction Code ");
		joinpoint.proceed();
		org.aspectj.lang.Signature signature = joinpoint.getSignature();
		System.out.println("after transaction Code "+signature.getName());
	}
}
