/**
 * 
 */
package com.pkg.capgemini.springBootDemo;

import org.springframework.stereotype.Component;

/**
 * @author digadade
 *
 */
@Component
public class HelloWorld {
	
	public void sayHello(){
		System.out.println("Hello");
	}
}
