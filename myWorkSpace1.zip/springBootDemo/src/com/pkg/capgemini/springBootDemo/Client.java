/**
 * 
 */
package com.pkg.capgemini.springBootDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * @author digadade
 *
 */
@Configuration
@EnableAutoConfiguration
@ComponentScan("com.pkg.capgemini.springBootDemo")
public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		ApplicationContext applicationContext = SpringApplication.run(Client.class, args);
		
		HelloWorld helloWorld = (HelloWorld) applicationContext.getBean("helloWorld");
		helloWorld.sayHello();
	}

}
