/**
 * 
 */
package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author digadade
 *
 */

@RestController
public class WelcomeController {
	
	@GetMapping("/hello/{name}")
	public String sayHello(@PathVariable("name") String name){
		return "hello "+name;
	}
	
	@RequestMapping(value="/emp",method=RequestMethod.POST)
	public Employee getEmployee(@RequestBody Employee employee){
		return employee;
	}
}
