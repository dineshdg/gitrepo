/**
 * 
 */
package com.example.demo;

import org.springframework.beans.factory.config.SetFactoryBean;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

/**
 * @author digadade
 *
 */
public class RestClient {
	
	public static void main(String[] args){
		//String url = "http://localhost:9091/hello";
		
		String url = "http://localhost:9091/emp";
		RestTemplate  restTemplate = new RestTemplate();
		Employee employee = new Employee();
		employee.setFname("ABC");
		employee.setLname("XYZ");
		
		ResponseEntity<Employee> employees = restTemplate.postForEntity(url, employee, Employee.class);
		System.out.println(employees.toString());
	}
}
