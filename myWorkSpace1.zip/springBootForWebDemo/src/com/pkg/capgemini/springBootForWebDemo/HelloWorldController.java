/**
 * 
 */
package com.pkg.capgemini.springBootForWebDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @author digadade
 *
 */
@Controller
@EnableAutoConfiguration
public class HelloWorldController {

	public static void main(String[] args){
		SpringApplication.run(HelloWorldController.class, args);
	}
	
	@RequestMapping(value="/cg")
	@ResponseBody
	public String sayHello(){
		return "Hello Client";
	}
}
