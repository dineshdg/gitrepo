/**
 * 
 */
package com.pkg.capgemini.springAOPDemo.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.pkg.capgemini.springAOPDemo.targetObject.BankAccount;

/**
 * @author digadade
 *
 */
public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("configData.xml");
		BankAccount account = (BankAccount) applicationContext.getBean("targetBean",BankAccount.class);
		
		account.deposite();
		account.withdrow(123244D);
	}

}
