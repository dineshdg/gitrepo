/**
 * 
 */
package com.pkg.capgemini.springAOPDemo.advices;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;


/**
 * @author digadade
 *
 */
@Aspect
public class MyAdvice {
	
	@Pointcut("execution(* com.pkg.capgemini.*.d*(..))")
	public void apply(){
		
	}
	
	public void validate() {
		System.out.println("Security Code");
	}
	
	@Before("apply()")
	public void doLogin(){
		System.out.println("login Code");
	}
	
	/*public void managetransaction(ProceedingJoinPoint joinpoint) throws Throwable{
		System.out.println("before transaction Code ");
		joinpoint.proceed();
		org.aspectj.lang.Signature signature = joinpoint.getSignature();
		System.out.println("after transaction Code "+signature.getName());
	}*/
}
