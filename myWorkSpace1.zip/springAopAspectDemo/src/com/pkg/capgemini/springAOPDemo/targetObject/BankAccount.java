/**
 * 
 */
package com.pkg.capgemini.springAOPDemo.targetObject;

/**
 * @author digadade
 *
 */
public class BankAccount {
	
	public void deposite(){
		System.out.println("diposite code");
	}
	
	public void withdrow(Double amount){
		System.out.println("withdrow amount :"+amount);
	}
}
