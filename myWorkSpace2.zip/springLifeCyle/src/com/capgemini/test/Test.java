package com.capgemini.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.pkg.capgemini.springLifeCyle.Student;

public class Test {
	
	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationConfig.xml");
		Student student = (Student) applicationContext.getBean("studentBean");
		/*//System.out.println(employeeService.getAllEmployees());
		ConfigurableApplicationContext configurableApplicationContext = (ConfigurableApplicationContext) applicationContext;
		configurableApplicationContext.close();*/
		
		((AbstractApplicationContext) applicationContext).registerShutdownHook();
	}

}
