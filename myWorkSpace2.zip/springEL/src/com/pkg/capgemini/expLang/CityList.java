/**
 * 
 */
package com.pkg.capgemini.expLang;

import java.util.List;

/**
 * @author digadade
 *
 */
public class CityList {

	List<Citiy> cities;

	public List<Citiy> getCities() {
		return cities;
	}

	public void setCities(List<Citiy> cities) {
		this.cities = cities;
	}

	@Override
	public String toString() {
		return "CityList [cities=" + cities + "]";
	}
	
	
}
