/**
 * 
 */
package com.pkg.capgemini.expLang;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author digadade
 *
 */
public class SpelTest {

	/**
	 * @param args
	 */
	@SuppressWarnings({ "unchecked", "resource" })
	public static void main(String[] args) {
			ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationConfig.xml");
			
			/*Employee employee = (Employee) applicationContext.getBean("empBean");
			System.out.println(employee);
			
			Person person = (Person) applicationContext.getBean("personBean");
			System.out.println(person);*/
			
			/*Citiy citiy1 = (Citiy) applicationContext.getBean("city1");
			System.out.println(citiy1);
			
			Citiy citiy2 = (Citiy) applicationContext.getBean("city2");
			System.out.println(citiy2);*/
			
			/*List<CityList> citiys = (ArrayList<CityList>) applicationContext.getBean("cityList");
			
			for (CityList citi : citiys) {
				System.out.println(citi);
			}*/
			
			
			User user = (User) applicationContext.getBean("userBean");
			System.out.println(user);
	}

}
