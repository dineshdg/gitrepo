/**
 * 
 */
package com.pkg.capgemini.expLang;

/**
 * @author digadade
 *
 */
public class User {
	
	private String uName;
	private String uPassword;
	
	public String getuName() {
		return uName;
	}
	public void setuName(String uName) {
		this.uName = uName;
	}
	public String getuPassword() {
		return uPassword;
	}
	public void setuPassword(String uPassword) {
		this.uPassword = uPassword;
	}
	@Override
	public String toString() {
		return "User [uName=" + uName + ", uPassword=" + uPassword + "]";
	}

}
