/**
 * 
 */
package com.pkg.capgemini.expLang;

/**
 * @author digadade
 *
 */
public class Citiy {
	
	private int cityId;
	private String cityName;
	private String cityState;
	private Long cityPopulation;
	
	public int getCityId() {
		return cityId;
	}
	public void setCityId(int cityId) {
		this.cityId = cityId;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getCityState() {
		return cityState;
	}
	public void setCityState(String cityState) {
		this.cityState = cityState;
	}
	public Long getCityPopulation() {
		return cityPopulation;
	}
	public void setCityPopulation(Long cityPopulation) {
		this.cityPopulation = cityPopulation;
	}
	@Override
	public String toString() {
		return "Citiy [cityId=" + cityId + ", cityName=" + cityName
				+ ", cityState=" + cityState + ", cityPopulation="
				+ cityPopulation + "]";
	}
	

}
