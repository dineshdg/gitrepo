package com.pkg.capgemini.model;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloWorldController {

	/*@RequestMapping("/hello")  
    public ModelAndView helloWorld() {  
        String message = "HELLO SPRING MVC HOW R U";
        return new ModelAndView("helloWorld", "message", message);  
    }  */
	
	@RequestMapping(value="/sendMsg",method=RequestMethod.POST)  
    public ModelAndView sendMsg(Model model,@RequestParam("message") String message) {  
        return new ModelAndView("helloWorld", "message", message);  
    }  
	
	@RequestMapping(value="/authenticate",method=RequestMethod.POST)  
    public String login(Model model,@RequestParam("uname") String uname,@RequestParam("upass") String upass) {  
		if(uname.equalsIgnoreCase("ddg") && upass.equalsIgnoreCase("ddg"))
			return "success";
		else
			return "failure";  
	}
	@RequestMapping(value="/login",method=RequestMethod.GET)  
	public String goTOHomePage(){
		return "login";
		
	}
}
