/**
 * 
 */
package com.pkg.capgemini.trainee.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.pkg.capgemini.trainee.dao.TraineeMgmtDAO;
import com.pkg.capgemini.trainee.dataModel.Trainee;

/**
 * @author digadade
 *
 */
@Component("traineeMgmtService")
public class TraineeMgmtServiceImpl implements TraineeMgmtService {
	
	@Autowired
	TraineeMgmtDAO traineeMgmtDAO;

	@Override
	public String verifyUser(Trainee trainee) {
		String response = traineeMgmtDAO.verifyUser(trainee);
		return response;
	}

	@Override
	public Trainee addTrainee(Trainee trainee) throws Exception{
		return traineeMgmtDAO.addTrainee(trainee);
	}

	@Override
	public Trainee searchTrainee(int id) {
		return traineeMgmtDAO.searchTrainee(id);
	}
}
