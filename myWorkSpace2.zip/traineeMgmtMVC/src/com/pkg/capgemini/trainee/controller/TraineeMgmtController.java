/**
 * 
 */
package com.pkg.capgemini.trainee.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.pkg.capgemini.trainee.dataModel.Trainee;
import com.pkg.capgemini.trainee.enumType.TraineeOperationEnums;
import com.pkg.capgemini.trainee.service.TraineeMgmtService;

/**
 * @author digadade
 *
 */
@Controller
public class TraineeMgmtController {
	
	@Autowired
	TraineeMgmtService traineeMgmtService;
	
	@Autowired
	@Qualifier("traineeValidator")
	private Validator validator;
	
	@InitBinder
    protected void initBinder(WebDataBinder binder) {
       binder.setValidator(validator);
    }
	
	@RequestMapping(value="/trainee", method=RequestMethod.GET)
	public String homePage(Model model){
		model.addAttribute("trainee", new Trainee());
		return "login";
	}
	
	@RequestMapping(value="/authenticate", method=RequestMethod.POST)
	public String authenticateUser(@Valid Trainee trainee,  BindingResult result){
		String response = "success";
        if (result.hasErrors()){
        	response = "errorsPage";
	    }else{
	    	response= traineeMgmtService.verifyUser(trainee);
	    }
		return response;
	}
	
	@RequestMapping(value="/trainee/{operation}")
	public ModelAndView addTrainee(Model model,@PathVariable("operation") String operation){
		model.addAttribute("manageTraineeData", new Trainee());
		String response = "errorPage";
		List<Trainee> trainees = new ArrayList<Trainee>();
		
		if(operation.equalsIgnoreCase(TraineeOperationEnums.Add.name())){
			model.addAttribute("location",new String[]{"Chennai","Banglore","Pune","Mumbai"});
			response = "addTrainee";
			return new ModelAndView(response);
		}else if(operation.equalsIgnoreCase(TraineeOperationEnums.Delete.name())){
			response = "deleteTrainee";
			
		}else if(operation.equalsIgnoreCase(TraineeOperationEnums.Modify.name())){
			response = "modifyTrainee";
		}else if(operation.equalsIgnoreCase(TraineeOperationEnums.Retrieve.name())){
			response = "retrieveTrainee";
		}else if(operation.equalsIgnoreCase(TraineeOperationEnums.RetrieveAll.name())){
			response = "retrieveAllTrainee";
		}
		return new ModelAndView(response);
	}
	
	@RequestMapping(value="/manageTraineeData/{operation}")
	public ModelAndView manageTraineeData(Model model,@PathVariable("operation") String operation,
					@ModelAttribute("trainee") Trainee trainee){
		String response = "errorPage";
		try{
			model.addAttribute("trainee", new Trainee());
			if(operation.equalsIgnoreCase(TraineeOperationEnums.Add.name())){
				if(trainee != null){
					trainee  = traineeMgmtService.addTrainee(trainee);
					response = "success";
				}
			}else if(operation.equalsIgnoreCase(TraineeOperationEnums.Delete.name())){
				if(trainee != null){
					trainee  = traineeMgmtService.searchTrainee(trainee.getId());
					response = "success";
				}
			}
		}catch (Exception e){
			e.printStackTrace();
			return new ModelAndView(response,"trainee",trainee);
		}
		return new ModelAndView(response,"trainee",trainee);
	}
}
