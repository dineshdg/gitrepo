/**
 * 
 */
package org.capgemini.com;

/**
 * @author digadade
 *
 */
public class MRF {
	public MRF(){
		System.out.println("MRF Used");
	}
}
