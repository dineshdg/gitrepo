package org.capgemini.com;

public class Wheel {
	MRF mrf;
	BridgStone bridgStone;
	
	public MRF getMrf() {
		return mrf;
	}

	public void setMrf(MRF mrf) {
		this.mrf = mrf;
	}

	public BridgStone getBridgStone() {
		return bridgStone;
	}

	public void setBridgStone(BridgStone bridgStone) {
		this.bridgStone = bridgStone;
	}

	public Wheel(MRF mrf){
		System.out.println("Wheels Are MRF");
	}
	
	public Wheel(BridgStone bridgStone){
		System.out.println("Wheels Are BridgStone");
	}
	
	public Wheel(){
		System.out.println("Wheel Created");
	}
}
