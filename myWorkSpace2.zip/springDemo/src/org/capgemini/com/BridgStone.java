/**
 * 
 */
package org.capgemini.com;

/**
 * @author digadade
 *
 */
public class BridgStone {
	public BridgStone(){
		System.out.println("BridgStone Used");
	}
}
