package org.capgemini.com;

public class Car {
	
	public Car(){
		System.out.println("Car Created");
	}
	
	public Car(Wheel wheel){
		System.out.println("wheel is injected in Car");
	}
	
	public Wheel wheel;
	
	public void moveCar(){
		System.out.println("");
	}

	public Wheel getWheel() {
		return wheel;
	}

	public void setWheel(Wheel wheel) {
		this.wheel = wheel;
	}
	
}
