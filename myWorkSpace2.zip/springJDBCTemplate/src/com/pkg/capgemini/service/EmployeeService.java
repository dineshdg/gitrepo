/**
 * 
 */
package com.pkg.capgemini.service;

import java.util.List;
import java.util.Map;

import com.pkg.capgemini.JDBCTemplate.Employee;

/**
 * @author digadade
 *
 */
public interface EmployeeService {
	
	int addEmployee(Employee employee);
	
	Employee getEmployeebyId(int id);
	
	Employee updateEmployeeById(int id);
	
	int deletEmployeeById(int id);
	
	List<Map<String, Object>> getAllEmployees();
}
