/**
 * 
 */
package com.pkg.capgemini.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;

import com.pkg.capgemini.JDBCTemplate.Employee;
import com.pkg.capgemini.Mapper.EmployeeMapper;

/**
 * @author digadade
 *
 */
public class EmployeeServiceImpl implements EmployeeService{

	JdbcTemplate jt;
	
	public void setJt(JdbcTemplate jt) {
		this.jt = jt;
	}
	
	@Override
	public int addEmployee(Employee employee) {
		String query = "insert into employee values(?,?,?)";
		return jt.update(query, employee.getEmployeeId(),employee.getEmployeeName(),employee.getSalary());
	}

	@Override
	public Employee getEmployeebyId(int id) {
		String selectQuery = "select * from employee where empId=?";
		Employee empployee = jt.queryForObject(selectQuery, new EmployeeMapper(),id);
		return empployee;
	}

	@Override
	public Employee updateEmployeeById(int id) {
		String upadatetQuery = "update employee set empName=? where empId=?";
		jt.update(upadatetQuery, "XYZ",id);
		return getEmployeebyId(id);
	}

	@Override
	public int deletEmployeeById(int id) {
		String deleteQuery = "delete from employee where empId=?";
		return jt.update(deleteQuery, id);
	}

	@Override
	public List<Map<String, Object>> getAllEmployees() {
		String selectAllQuery = "select * from employee";
		/*List<Employee> empployee = jt.query(selectAllQuery, new EmployeeMapper());
		return empployee;*/
		
		List<Map<String, Object>> employees = jt.queryForList(selectAllQuery);
		
		//List<Employee> empployee = new ArrayList<Employee>(employees);
		
		return employees;
	}

}
