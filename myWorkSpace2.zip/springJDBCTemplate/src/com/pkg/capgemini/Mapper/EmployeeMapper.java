/**
 * 
 */
package com.pkg.capgemini.Mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.pkg.capgemini.JDBCTemplate.Employee;

/**
 * @author digadade
 *
 */
public class EmployeeMapper implements RowMapper<Employee>{

	@Override
	public Employee mapRow(ResultSet rs, int arg1) throws SQLException {
		Employee employee = new Employee(rs.getInt(1), rs.getString(2), rs.getDouble(3));
		return employee;
	}
	
}
