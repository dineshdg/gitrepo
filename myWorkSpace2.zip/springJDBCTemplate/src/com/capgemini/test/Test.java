package com.capgemini.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.pkg.capgemini.JDBCTemplate.Employee;
import com.pkg.capgemini.service.EmployeeService;




public class Test {
	
	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationConfig.xml");
		EmployeeService employeeService = (EmployeeService) applicationContext.getBean("empServiceBean");
		
		Employee employee = new Employee();
		employee.setEmployeeId(1);
		employee.setEmployeeName("ABC");
		employee.setSalary(Math.random() * 100.0);
		
		//System.out.println(employeeService.addEmployee(employee));
		//System.out.println(employeeService.getEmployeebyId(2));
		//System.out.println(employeeService.updateEmployeeById(1));
		//System.out.println(employeeService.deletEmployeeById(2));
		System.out.println(employeeService.getAllEmployees());
	}

}
