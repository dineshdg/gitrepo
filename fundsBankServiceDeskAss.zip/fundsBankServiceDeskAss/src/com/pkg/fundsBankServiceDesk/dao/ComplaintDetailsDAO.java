/**
 * 
 */
package com.pkg.fundsBankServiceDesk.dao;

import java.util.List;

import com.pkg.fundsBankServiceDesk.model.ComplaintDetails;

/**
 * @author digadade
 *
 */
public interface ComplaintDetailsDAO {

	int createNewComplaint(ComplaintDetails complaintDetails) throws Exception;

	//List<Map<String, Object>> searchByComplaintId(int complaintId) throws Exception;

	List<ComplaintDetails> findById(int id);

}
