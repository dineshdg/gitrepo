/**
 * 
 */
package com.pkg.fundsBankServiceDesk.dao;

import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.pkg.fundsBankServiceDesk.model.ComplaintDetails;

/**
 * @author digadade
 *
 */

@Component("complaintDetailsDAO")
@Transactional
public class ComplaintDetailsDAOImpl implements ComplaintDetailsDAO{

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public int createNewComplaint(ComplaintDetails complaintDetails) throws Exception {

		entityManager.persist(complaintDetails);
		entityManager.flush();	//required to reflect changes on database
		//return employee;
		
		if(complaintDetails != null)
			return complaintDetails.getComplaintId();
		else
			return 0;
	}

	/*@Override
	public List<Map<String, Object>> searchByComplaintId(int complaintId) throws Exception{
		String selectAllQuery = "select * from complaint where complaintid=?";
		return jt.queryForList(selectAllQuery,complaintId);
	}*/
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ComplaintDetails> findById(int id) {
		/*Query query = 
				entityManager.createQuery("FROM complaintdetails where complaintid = ?",ComplaintDetails.class);
		query.setParameter(1, id);
		return query.getResultList();*/
		return Arrays.asList(entityManager.find(ComplaintDetails.class, id));
	}

}
