/**
 * 
 */
package com.pkg.fundsBankServiceDesk.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.pkg.fundsBankServiceDesk.model.ComplaintDetails;
import com.pkg.fundsBankServiceDesk.service.ComplaintDetailsService;

/**
 * @author digadade
 *
 */
@Controller
public class FundsBankComplaintController {
	
	@Autowired
	private ComplaintDetailsService complaintDetailsService;
	
	@Autowired
	@Qualifier("complaintDetailsValidator")
	private Validator validator;

	
	@InitBinder
    protected void initBinder(WebDataBinder binder) {
       binder.setValidator(validator);
    }
	
	@RequestMapping(value="/complaintDetails", method=RequestMethod.GET)
	public String homePage(Model model){
		model.addAttribute("complaintDetails", new ComplaintDetails());
		return "raiseComplaint";
	}
	
	@RequestMapping(value="/createComplaint", method=RequestMethod.POST)
	public ModelAndView createcomplaint(Model model, @ModelAttribute("complaintDetails") @Valid ComplaintDetails complaintDetails, BindingResult result){
		try{
			if(result.hasErrors()){
				return new ModelAndView("raiseComplaint");
			}
			
			//save complaint details with all required validation
			int complaintId = complaintDetailsService.createNewComplaint(complaintDetails);
			if(complaintId > 0 )
				 return new ModelAndView("complaintDetailsSuccess", "complaintId", complaintId);
			else
				return new ModelAndView("errorPage");
		}catch(Exception e){
			e.printStackTrace();
			return new ModelAndView("errorPage");
		}
	}
	
	@RequestMapping(value="/searchResult", method=RequestMethod.GET)
	public ModelAndView statusDetails(Model model, @ModelAttribute("complaintDetails") ComplaintDetails complaintDetails,  BindingResult result){
		try{
			model.addAttribute("searchResult", new ComplaintDetails());
			//List<Map<String, Object>> complaintList = complaintDetailsService.searchByComplaintId(complaintDetails.getComplaintId());
			List<ComplaintDetails> complaintList = complaintDetailsService.findById(complaintDetails.getComplaintId());
			return new ModelAndView("searchResult", "complaintList", complaintList);
		}catch(Exception e){
			e.printStackTrace();
			return new ModelAndView("errorPage");
		}
	}
}
