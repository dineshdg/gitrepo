/**
 * 
 */
package com.pkg.fundsBankServiceDesk.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.pkg.fundsBankServiceDesk.dao.ComplaintDetailsDAO;
import com.pkg.fundsBankServiceDesk.model.ComplaintDetails;

/**
 * @author digadade
 *
 */

@Component("complaintDetailsService")
public class ComplaintDetailsServiceImpl implements ComplaintDetailsService{
	
	@Autowired
	private ComplaintDetailsDAO complaintDetailsDAO;
	
	@Override
	public int createNewComplaint(ComplaintDetails complaintDetails) throws Exception {
		if(complaintDetails.getCategory().equalsIgnoreCase("Internet Banking"))
			complaintDetails.setPriority("High");
		else if(complaintDetails.getCategory().equalsIgnoreCase("General Banking"))
			complaintDetails.setPriority("Medium");
		else
			complaintDetails.setPriority("Low");
		
		complaintDetails.setStatus("Open");
		return complaintDetailsDAO.createNewComplaint(complaintDetails);
	}

	/*@Override
	public List<Map<String, Object>> searchByComplaintId(int complaintId) throws Exception{
		return complaintDetailsDAO.searchByComplaintId(complaintId);
	}*/

	@Override
	public List<ComplaintDetails> findById(int id) {
		return complaintDetailsDAO.findById(id);
	}

}
