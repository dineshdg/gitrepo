/**
 * 
 */
package com.pkg.fundsBankServiceDesk.validator;

import java.util.regex.Pattern;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.pkg.fundsBankServiceDesk.model.ComplaintDetails;

/**
 * @author digadade
 *
 */

@Component
public class ComplaintDetailsValidator implements Validator{

	@Override
	public boolean supports(Class<?> arg0) {
		return ComplaintDetails.class.isAssignableFrom(arg0);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "accountId", "account.id.empty");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "branchCode", "branch.code.empty");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "emailId", "email.id.empty");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "category", "category.empty");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "description", "description.empty");
		
		ComplaintDetails complaintDetails = (ComplaintDetails) obj;
		if(complaintDetails.getAccountId() == null)
			errors.reject("accountId", "account.id.invalid");
		
		if(complaintDetails.getEmailId() != ""){
			Pattern pattern = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$",Pattern.CASE_INSENSITIVE);
		    if (!(pattern.matcher(complaintDetails.getEmailId()).matches())) {
		    	errors.rejectValue("emailId", "email.id.invalid");
		    }
		}
	}

}
