/**
 * 
 */
package com.pkg.capgemini.springRESTfulDemo;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author digadade
 *
 */

@RestController
@RequestMapping(value="/pc")

public class SpringRestController {
	
	
	/*@RequestMapping(value="/{msg}", method = RequestMethod.GET)
	public String showMessage(Model model, @PathParam("msg") String message){
		return message;
	}*/
	
	/*@RequestMapping(value = "/{name}", method = RequestMethod.GET)
	public String sayHello(@PathVariable String name) {
		String result = "Welcome " + name + " to Spring session!!!";
		return result;
	}*/
	
	/*@Path("/getEmployeeData")
	@GET
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_XML)
	public Employee getEmployeeData(){
		Employee employee = new Employee();
		employee.setId(1);
		employee.setName("ABC");
		employee.setSalary(132434d);
		return employee;
	}*/
	@RequestMapping(value="/getAllEmployeeByMVC", method=RequestMethod.GET)
	@Produces(value=MediaType.APPLICATION_XML)
	public List<Employee> getAllEmployee(){
		List<Employee> empList = new ArrayList<Employee>();
		empList.add(new Employee(1,"ABC",12312d));
		empList.add(new Employee(2,"DDG",11232d));
		empList.add(new Employee(3,"PQR",13452d));
		empList.add(new Employee(4,"XYZ",12452d));
		
		return empList; 
	}
	@RequestMapping(value = "/getEmployeeDataByMVC", method=RequestMethod.GET)
	//@Consumes(MediaType.APPLICATION_JSON)
	@Produces(value=MediaType.APPLICATION_JSON)
	public Employee getEmployeeDataByMVC(){
		Employee employee = new Employee();
		employee.setId(1);
		employee.setName("ABC");
		employee.setSalary(132434d);
		return employee;
	}
	
}
