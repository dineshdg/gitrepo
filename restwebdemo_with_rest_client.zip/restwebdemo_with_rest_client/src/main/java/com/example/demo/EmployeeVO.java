package com.example.demo;

public class EmployeeVO {
   public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
   private String name;
   private String dept;
	
}
